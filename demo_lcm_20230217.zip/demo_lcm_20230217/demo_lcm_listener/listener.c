// file: listener.c
//
// LCM example program.
//
// compile with:
//  $ gcc -o listener listener.c -llcm
//
// On a system with pkg-config, you can also use:
//  $ gcc -o listener listener.c `pkg-config --cflags --libs lcm`

#include <inttypes.h>
#include "lcm/lcm.h"
#include <stdio.h>
#include<sys/time.h>
#include "GPS_Message_Type.h"

static void my_handler(const lcm_recv_buf_t *rbuf, const char *channel, const GPS_Message_Type *msg,
                       void *user)
{
    printf("Received message on channel \"%s\":\n", channel);
    
    struct timeval tv;
	gettimeofday(&tv,NULL);
	int64_t time_usec = tv.tv_sec*1000000+tv.tv_usec;

    printf("  times_now   = %" PRId64 "\n" , time_usec);
    printf("  timestamp   = %" PRId64 "\n", msg->si64_timestamp);
    printf("time_differences = %.6lf\n",(double)(time_usec-msg->si64_timestamp) / 1000000.0);

    printf("  position    = (%f, %f, %f)\n", msg->f64_lon, msg->f64_lat, msg->f64_alt);
    printf("\n");
}

int main(int argc, char **argv)
{
    lcm_t *lcm = lcm_create("udpm://239.255.76.67:7667?ttl=1");

    printf("hello");
    fflush(stdout);

    if (!lcm)
        return 1;

    GPS_Message_Type_subscribe(lcm, "GPS_Message", &my_handler, NULL);

    while (1)
    {
        lcm_handle(lcm);
    }
        
    lcm_destroy(lcm);
    return 0;
}
